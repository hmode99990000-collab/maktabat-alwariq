export default function App() {
  const books = [
    { title: "فن الرسم الزيتي", category: "فنون" },
    { title: "تاريخ الحضارات", category: "تاريخ" },
    { title: "تعلم البرمجة", category: "تقنية" }
  ];

  return (
    <div style={{fontFamily:'sans-serif',direction:'rtl',padding:'20px'}}>
      <h1>مكتبة الوارق</h1>
      <p>أهلاً بك في مكتبة الوارق - اكتشف الكتب والمعرفة</p>

      <h2>الأقسام</h2>
      <ul>
        <li>روايات</li>
        <li>فنون</li>
        <li>برمجة</li>
        <li>تاريخ</li>
      </ul>

      <h2>كتب مميزة</h2>
      {books.map((b,i)=>(
        <div key={i} style={{background:'#fff',padding:'10px',margin:'10px 0'}}>
          <h3>{b.title}</h3>
          <p>{b.category}</p>
        </div>
      ))}

      <h2>من نحن</h2>
      <p>مكتبة الوارق منصة إلكترونية للكتب والمعرفة.</p>
    </div>
  );
}
